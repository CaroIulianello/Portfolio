#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <ctime>
#include <mpi.h>
using namespace std;

enum stati{MORTA='.', VIVA='*', LIVE=1};

int N=1000;
double start=0.0;
double end=0.0;

void riempi(char **);
void stampa(char **);
void gioca1(char **, char **);
void gioca2(char **, char *);
int casi(char **, int, int, int);
void distruttore(char**);

bool NO(int, int);
bool NE(int, int);
bool SO(int, int);
bool SE(int, int);
bool NBordo(int, int);
bool SBordo(int, int);
bool SinBordo(int, int);
bool DesBordo(int, int);

int main()
{
   int nproc, myId;
   
   char **B=new char*[N];
   int gen=0;
   
   MPI_Init(0,0);
   MPI_Status status;
   MPI_Comm_size(MPI_COMM_WORLD, &nproc);
   MPI_Comm_rank(MPI_COMM_WORLD, &myId); 
   MPI_Wtime();
   
   riempi(B);
   
   MPI_Barrier(MPI_COMM_WORLD);
   start=MPI_Wtime();
   
   while(gen<300)
   {
      if(myId==0)
      {
         char **temp1=new char *[N/2];
         char *temp3=new char[(N*N)/2];
         
         for(int i=0; i<N/2; i++)
            temp1[i]=new char[N];
         
         //stampa(B);
         gioca1(B,temp1);
         
         //svuota temp1 in B
         for(int i=0; i<N/2; i++)
            for(int j=0; j<N; j++)
               B[i][j]=temp1[i][j];
         
         MPI_Recv(&temp3[0], (N*N)/2, MPI_CHAR, 1, 10, MPI_COMM_WORLD, &status);
         
         int k=0;
         //svuota temp3 in B
         for(int i=N/2; i<N; i++)
            for(int j=0; j<N; j++)
               B[i][j]=temp3[k++];
         
          for(int i=0; i<N/2; i++)
            delete []temp1[i];
            
          delete []temp1;
      }
      
      if(myId==1)
      {
         char *temp2=new char[(N*N)/2];
         
         gioca2(B,temp2);
        
         int k=0;
         //svuota temp2 in B
         for(int i=N/2; i<N; i++)
            for(int j=0; j<N; j++)
               B[i][j]=temp2[k++];
         
         MPI_Send(temp2, (N*N)/2, MPI_CHAR, 0, 10, MPI_COMM_WORLD);
         
         delete []temp2;
      }
      gen++;
   }
   
   distruttore(B);
   
   MPI_Barrier(MPI_COMM_WORLD);
   end=MPI_Wtime();
   
   MPI_Finalize();

   if(myId==0)
      cout<<"Il tempo impiegato e': "<<end-start<<endl;
   
return 0;
}

void riempi(char **B)
{
   srand(time(NULL));
   int v=N*N*0.3;
   int m=N*N*0.7;
   
   int s;
   for(int i=0; i<N; i++)
      B[i]=new char[N];
    
   for(int i=0; i<N; i++)
      for(int j=0; j<N; j++)
      {
         s=rand()%10;
         if(m>0 && s>=3 && s<=10 || v==0)
         {
            m--;
            B[i][j]=MORTA;
         }
         
         else if(v>=0)
         {
            v--;
            B[i][j]=VIVA;
         }
      }
}

void stampa(char **B)
{
   for(int i=0; i<N; i++)
   {
      for(int j=0; j<N; j++)
         cout<<B[i][j]<<" ";
         
      cout<<endl;
   }
   
   sleep(1);
   cout<<"\n\n\n\n\n";
}     
         
bool NO(int i, int j)
{
   if(i==0 && j==0)
      return true;

return false;
}

bool NE(int i, int j)
{
   if(i==0 && j==N-1)
      return true;
      
return false;
}

bool SO(int i, int j)
{
   if(i==N-1 && j==0)
      return true;
      
return false;
}

bool SE(int i, int j)
{
   if(i==N-1 && j==N-1)
      return true;
      
return false;
}

bool NBordo(int i, int j)
{
   if(i==0 && (j!=0 || j!=N-1))
      return true;
      
return false;
}

bool SBordo(int i, int j)
{
   if(i==N-1 && (j!=0 || j!=N-1))
      return true;
      
return false;
}

bool SinBordo(int i, int j)
{
   if((i!=0 || i!=N-1) && j==0)
      return true;

return false;
}

bool DesBordo(int i, int j)
{
   if((i!=0 || i!=N-1) && j==N-1)
      return true;
      
return false;
}         
         
int casi(char **B, int i, int j, int s)   
{
   int cont=0;
   
   if(NO(i,j))
   {
      if(B[i][j+1]==VIVA)
         cont++;
         
      if(B[i+1][j+1]==VIVA)
         cont++;
      
      if(B[i+1][j]==VIVA)
         cont++;
   }
   
   else if(NE(i,j))
   {
      if(B[i][j-1]==VIVA)
         cont++;
         
      if(B[i+1][j-1]==VIVA)
         cont++;
         
      if(B[i+1][j]==VIVA)
         cont++;
   }
   
   else if(SO(i,j))
   {
      if(B[i-1][j]==VIVA)
         cont++;
         
      if(B[i-1][j+1]==VIVA)
         cont++;
      
      if(B[i][j+1]==VIVA)
         cont++;
   }
   
   else if(SE(i,j))
   {
      if(B[i][j-1]==VIVA)
         cont++;
         
      if(B[i-1][j-1]==VIVA)
         cont++;
         
      if(B[i-1][j]==VIVA)
         cont++;
   }
   
   else if(NBordo(i,j))
   {
      if(B[i][j-1]==VIVA)
         cont++;
         
      if(B[i+1][j-1]==VIVA)
         cont++;
         
      if(B[i+1][j]==VIVA)
         cont++;
         
      if(B[i+1][j+1]==VIVA)
         cont++;
         
      if(B[i][j+1]==VIVA)
         cont++;
   }
   
   else if(SBordo(i,j))
   {
      if(B[i][j-1]==VIVA)
         cont++;
         
      if(B[i-1][j-1]==VIVA)
         cont++;
        
      if(B[i-1][j]==VIVA)
         cont++;
      
      if(B[i-1][j+1]==VIVA)
         cont++;
         
      if(B[i][j+1]==VIVA)
         cont++;
    }
    
    else if(SinBordo(i,j))
    {
      if(B[i-1][j]==VIVA)
         cont++;
         
      if(B[i-1][j+1]==VIVA)
         cont++;
         
      if(B[i][j+1]==VIVA)
         cont++;
      
      if(B[i+1][j+1]==VIVA)
         cont++;
         
      if(B[i+1][j]==VIVA)
         cont++;
    }
     
    else if(DesBordo(i,j))
    {
      if(B[i-1][j]==VIVA)
         cont++;
         
      if(B[i-1][j-1]==VIVA)
         cont++;
         
      if(B[i][j-1]==VIVA)
         cont++;
         
      if(B[i+1][j-1]==VIVA)
         cont++;
         
      if(B[i+1][j]==VIVA)
         cont++;
    }
    
    else 
    {
      if(B[i-1][j]==VIVA)
         cont++;
        
      if(B[i-1][j-1]==VIVA)
         cont++;
     
      if(B[i][j-1]==VIVA)
         cont++;
        
      if(B[i+1][j-1]==VIVA)
         cont++;
     
      if(B[i+1][j]==VIVA)
         cont++;
        
      if(B[i+1][j+1]==VIVA)
         cont++;
    
      if(B[i][j+1]==VIVA)
         cont++;
        
      if(B[i-1][j+1]==VIVA)
         cont++;
   }
    
   if(cont<2)
      return 0;
      
   if(cont>3)
      return 0;
      
   if((cont==2 || cont==3) && s==1)
      return LIVE;
      
   if(cont==3 && s==0)
      return LIVE;
}

void gioca1(char **B, char **temp1)
{ 
   for(unsigned i=0; i<N/2; i++)
      for(unsigned j=0; j<N; j++)
      {
         if(B[i][j]==VIVA)
         {
            if(casi(B,i,j,1)==0)
               temp1[i][j]=MORTA;
            
            else
               temp1[i][j]=VIVA;
         }
         
         else if(B[i][j]==MORTA)
         {
            if(casi(B,i,j,0)==LIVE)
               temp1[i][j]=VIVA;
               
             else
               temp1[i][j]=MORTA;
         }
      }
}

void gioca2(char **B, char *temp2)
{ 
   int k=0;
   for(unsigned i=N/2; i<N; i++)
      for(unsigned j=0; j<N; j++)
      {
         if(B[i][j]==VIVA)
         {
            if(casi(B,i,j,1)==0)
               temp2[k++]=MORTA;
            
            else
               temp2[k++]=VIVA;
         }
         
         else if(B[i][j]==MORTA)
         {
            if(casi(B,i,j,0)==LIVE)
               temp2[k++]=VIVA;
               
             else
               temp2[k++]=MORTA;
         }
      }
}
         
void distruttore(char **B)
{
	for(unsigned i=0; i<N;i++)
		delete[] B[i];
	
	delete[] B;
}            
