//La classe Barile gestisce un intero per definire il tipo, una booleana per verificare se l'oggetto è stato spostato ed un enum che indica la direzione. 
//L'oggetto Barile viene utilizzato nella classe Matrice come unità più piccola di una matrice di barili.

enum Direzione {RIGHT,DOWN,LEFT,UP,NONE};

class Barile
{
   private:
      int tipo;
      Direzione direzione; // 0 RIGHT, 1 DOWN, 2 LEFT, 3 UP, 4 NULLO
      bool spostato;

   public:
      Barile();
      Barile(int,Direzione);
      int getTipo() const;
      Direzione getDirezione() const;
      void setTipo(int);
      void setDirezione(Direzione);
      bool getSpostato() const;
      void setSpostato(bool);
};

Barile:: Barile()
{
   tipo=0;
   direzione=NONE;
}

Barile:: Barile(int t, Direzione d)
{
   tipo=t;
   direzione=d;
}

bool Barile:: getSpostato() const
{
   return spostato;
}

int Barile:: getTipo() const
{
   return tipo;
}

Direzione Barile:: getDirezione() const
{
   return direzione;
}

void Barile:: setTipo(int t)
{
   tipo=t;
}

void Barile:: setDirezione(Direzione d)
{
   direzione=d;
}

void Barile:: setSpostato(bool s)
{
   spostato=s;
}

