//La classe GameManager è la classe che gestisce tutti gli oggetti e le interazioni che avvengono fra di loro.
//Il GameManager contiene tutte le funzioni di Allegro5, una libreria grafica.

#include <allegro5/allegro.h>
#include "allegro5/allegro_image.h"
#include <iostream>
#include <time.h>
#include <list> 
#include <vector>
#include <stdio.h>      
#include <stdlib.h> 
#include"Matrice.h" 
#include "Player.h"
#include "Enemy.h"
#include "Corsaro.h"

const int FPS=10;
const int SCREEN_W = 1550;
const int SCREEN_H = 800;
enum MYKEYS {KEY_UP, KEY_DOWN, KEY_LEFT, KEY_RIGHT,KEY_SPACE, KEY_ENTER};

class GameManager
{
	private:
	   //Elementi Di Allegro per la Gestione del Gioco
		ALLEGRO_DISPLAY *display;
		ALLEGRO_DISPLAY_MODE disp_data;
		ALLEGRO_TIMER *timer1;
		ALLEGRO_TIMER *timer2;
		ALLEGRO_EVENT_QUEUE *event_queue;
		ALLEGRO_TRANSFORM t;
		//vector di Allegro_Bitmap 
		vector<ALLEGRO_BITMAP*> immaginiPg;
		vector<ALLEGRO_BITMAP*> immaginiEn;
		vector<ALLEGRO_BITMAP*> immaginiCo;
		vector<ALLEGRO_BITMAP*> immaginiPgI;

		ALLEGRO_BITMAP *barile;
		ALLEGRO_BITMAP *barilePreso;
		ALLEGRO_BITMAP *contorno;
		ALLEGRO_BITMAP *sfondo;
		ALLEGRO_BITMAP *menu1;
		ALLEGRO_BITMAP *vittoria;
		ALLEGRO_BITMAP *sconfitta;
		ALLEGRO_BITMAP *moneta;
		ALLEGRO_BITMAP *vita;

		Matrice *logica;
		Player *player;

      //Variabili per la gestione del Gioco
		bool doexit;
		bool redraw;
		int width;
		int height;
		int livello;
		bool key[6];
		
		//Vector di dati sui nemici(posizione/respawn)
		vector<Enemy*> nemici;
		vector<Coordinate> spawnCorsaro;
		vector<Corsaro *> corsari;
 
   public:
      GameManager();
      bool attivazione(ALLEGRO_EVENT);
      bool disattivazione(ALLEGRO_EVENT);
      bool getDoexit() const;
      void setDoexit(bool);
      void start();
      bool getRedraw() const;
      void setRedraw(bool);
      void Grafica();
      void avanzaDiLivello();
      void menu();
      ~GameManager();
};

GameManager:: GameManager()
{
   for(int i=0;i<6;i++) 
      key[i]=false;

   redraw=false;
   livello=0;
   
   al_init();
   al_init_image_addon();
   al_install_keyboard();

   timer1 = al_create_timer(1.0/FPS);  
   timer2 = al_create_timer(1.0/5);  

   //Funzioni per applicare il trasform ed effetuare la resize del display
   al_get_display_mode(0, &disp_data);   
   width=disp_data.width; 
   height=disp_data.height;
   
   float resize_y= height/static_cast<float>(SCREEN_H);
   float resize_x= width/static_cast<float>(SCREEN_W);
   
   al_set_new_display_flags(ALLEGRO_FULLSCREEN_WINDOW);

   display=al_create_display(SCREEN_W, SCREEN_H);

   al_identity_transform(&t);
   al_scale_transform(&t,resize_x,resize_y);
   al_use_transform(&t);

   logica=new Matrice(livello);
   
   //Caricamento delle immagini
   for(int i=0;i<4;i++)
   {
      ALLEGRO_BITMAP *p;
      ALLEGRO_BITMAP *e;
      ALLEGRO_BITMAP *c;
      ALLEGRO_BITMAP *pI;
      
      if(i==0)
      {
         c=al_load_bitmap("image/corsaroU.png");
         e=al_load_bitmap("image/marinaioR.png");
         p=al_load_bitmap("image/PgL.png");
         pI=al_load_bitmap("image/PgLO.png");
      }
      
      if(i==1)
      {
         c=al_load_bitmap("image/corsaroR.png");
         p=al_load_bitmap("image/PgR.png");
         e=al_load_bitmap("image/marinaioL.png");
         pI=al_load_bitmap("image/PgRO.png");
      }
      
      if(i==2)
      {
         c=al_load_bitmap("image/corsaroD.png");
         p=al_load_bitmap("image/PgD.png");
         e=al_load_bitmap("image/marinaioU.png");
         pI=al_load_bitmap("image/PgDO.png");
      }
      
      if(i==3)
      {
         c=al_load_bitmap("image/corsaroL.png");
         p=al_load_bitmap("image/PgU.png");
         e=al_load_bitmap("image/marinaioD.png");
         pI=al_load_bitmap("image/PgUO.png");
      }
      
      immaginiCo.push_back(c);
      immaginiPg.push_back(p);
      immaginiPgI.push_back(pI);
      immaginiEn.push_back(e);
   }
   
   sfondo=al_load_bitmap("image/sfondo.png");
   menu1=al_load_bitmap("image/menu.png");
   vittoria=al_load_bitmap("image/HaiVinto.png");
   sconfitta=al_load_bitmap("image/HaiPerso.png");
   contorno=al_load_bitmap("image/osso.png");
   barile=al_load_bitmap("image/barileAzzurro.png");
   barilePreso=al_load_bitmap("image/barileRosso.png");
   moneta=al_load_bitmap("image/moneta.png");
   vita=al_load_bitmap("image/pgDVite.png");
   event_queue = al_create_event_queue();
   player=new Player(0,0,true,3,DOWN,false,false);
}

//Metodo start(), è il metodo che gestisce l'intero gioco tramite cicli di while. Se il gioco si conclude con una vittoria o una sconfitta, si esce dal while e il metodo termina.
void GameManager:: start()
{
   livello=0;
   
   al_start_timer(timer1); 
   al_start_timer(timer2); 

   al_register_event_source(event_queue, al_get_display_event_source(display));
   al_register_event_source(event_queue, al_get_keyboard_event_source());
   al_register_event_source(event_queue, al_get_timer_event_source(timer1));
   al_register_event_source(event_queue, al_get_timer_event_source(timer2));

   setDoexit(false);
   menu();
   avanzaDiLivello();
   al_flip_display();
   int invincibile=0;
   bool attivata=false;

   while(!getDoexit())
   { 

      ALLEGRO_EVENT ev;
      al_wait_for_event(event_queue, &ev);
      
      if(ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
      	setDoexit(true);
      
      else if(ev.type == ALLEGRO_EVENT_KEY_DOWN) 
      	attivazione(ev);
      
      else if(ev.type == ALLEGRO_EVENT_KEY_UP) 
      	disattivazione(ev);
      
      //CONTROLLO CHIUSURA GIOCO/LIVELLO
      bool nemiciTuttiMorti=true;
      
      for(int i=0;i<nemici.size();i++)
      {
         if(nemici[i]->getVisibile())
            nemiciTuttiMorti=false;
      }
      
      if(nemiciTuttiMorti)
      {
         avanzaDiLivello();
         player->setBarile(false);
         player->setDistruttibile(false);
      }
      //FINE CONTROLLO

      if(getRedraw())
      {
         Grafica();
         al_flip_display(); 
      }
      
      if(ev.type==ALLEGRO_EVENT_TIMER)
      {
         setRedraw(true);
	      
	      if(ev.timer.source==timer1)
	      {		      	
	      	//CONTROLLO INVINCIBILITA'
	      	if(player->getContatoreBarili()==10)
	      	{
	      		player->setInvincibile(true);
	      		invincibile=0;
	      		attivata=true;
	      	}

	      	//CONTROLLO FINE INVINCIBILITA'
	      	if(invincibile==40 && attivata)
	      	{
	      		player->setInvincibile(false);
	      		player->azzeraContatoreBarili();
	      		invincibile=0;
	      		attivata=false;
	      	}

	      	else
	      		invincibile++;

		      //MOVIMENTO PLAYER
		      if(key[KEY_UP])
		      {
		         if(player->getX()>0 && logica->getInMappa(player->getX()-1,player->getY()).getTipo()==0 && player->getDirezione()==UP)
		         {
		            logica->setInLogica(player->getX(),player->getY(),'0');
		            player->setX(player->getX()-1);
		            logica->setInLogica(player->getX(), player->getY(),'P');
		         }
		         player->setVisibile(true);
		         player->setDirezione(UP);
		         setRedraw(true);
		      }
		 
		      if(key[KEY_DOWN])
		      {
		         if(player->getX()<logica->getRighe()-1 && logica->getInMappa(player->getX()+1,player->getY()).getTipo()==0 && player->getDirezione()==DOWN)
		         {
		            logica->setInLogica(player->getX(),player->getY(),'0');
		            player->setX(player->getX()+1);
		            logica->setInLogica(player->getX(), player->getY(),'P');
		         }
		         player->setVisibile(true);
		         player->setDirezione(DOWN);
		         setRedraw(true);
		      }
		 
		      if(key[KEY_LEFT])
		      {
		         if(player->getY()>0 && logica->getInMappa(player->getX(),player->getY()-1).getTipo()==0 && player->getDirezione()==LEFT)
		         {
		            logica->setInLogica(player->getX(),player->getY(),'0');
		            player->setY(player->getY()-1);
		            logica->setInLogica(player->getX(), player->getY(),'P');
		         }
		         player->setVisibile(true); 
		         player->setDirezione(LEFT);
		         setRedraw(true);
		      }

		      if(key[KEY_RIGHT])
		      {
		         if(player->getY()<logica->getColonne() && logica->getInMappa(player->getX(),player->getY()+1).getTipo()==0 && player->getDirezione()==RIGHT)
		         {
		            logica->setInLogica(player->getX(),player->getY(),'0');
		            player->setY(player->getY()+1);
		            logica->setInLogica(player->getX(), player->getY(),'P');
		         }
		         player->setVisibile(true);
		         player->setDirezione(RIGHT);
		         setRedraw(true);
		      }

		      //SE IL PLAYER NON HA IL BARILE (DISTRUTTIBILI), CON IL TASTO SPACE LO PRENDE
		      if(key[KEY_SPACE] && player->getBarile()==false && player->getVisibile())
		      {
		         if(player->getDirezione()==UP && player->getX()>0 && logica->getInMappa(player->getX()-1, player->getY()).getTipo()==1)
		         {
		            logica->setInMappa(player->getX()-1,player->getY(),0);
		            player->setBarile(true);
		            player->setDistruttibile(true);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		            player->incrementaContatoreBarili();
		         }
		      
		         if(player->getDirezione()==DOWN && player->getX()<logica->getRighe() && logica->getInMappa(player->getX()+1, player->getY()).getTipo()==1)
		         {
		            logica->setInMappa(player->getX()+1,player->getY(),0);
		            player->setBarile(true);
		            player->setDistruttibile(true);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		            player->incrementaContatoreBarili();
		         }
		      
		         if(player->getDirezione()==LEFT && player->getY()>0 && logica->getInMappa(player->getX(),player->getY()-1).getTipo()==1)
		         {
		            logica->setInMappa(player->getX(),player->getY()-1,0);
		            player->setBarile(true);
		            player->setDistruttibile(true);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		            player->incrementaContatoreBarili();
		         }
		      
		         if(player->getDirezione()==RIGHT && player->getY()<logica->getColonne() && logica->getInMappa(player->getX(),player->getY()+1).getTipo()==1)
		         {
		            logica->setInMappa(player->getX(),player->getY()+1,0);
		            player->setBarile(true);
		            player->setDistruttibile(true);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		            player->incrementaContatoreBarili();
		         }
		      } //FINE CONTROLLO

		      //SE IL PLAYER HA GIA IL BARILE, CON IL TASTO SPACE LO LANCIA
		      if(key[KEY_SPACE] && player->getBarile()==true && player->getDistruttibile()==true && player->getVisibile())
		      {
		         if(player->getDirezione()==UP && player->getX()>0 && logica->getInMappa(player->getX()-1, player->getY()).getTipo()==0)
		         {
		            logica->setInMappa(player->getX()-1,player->getY(),3);
		            logica->setInMappaDirezione(player->getX()-1,player->getY(),UP);
		            player->setBarile(false);
		            player->setDistruttibile(false);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		         }

		         if(player->getDirezione()==DOWN && player->getX()<logica->getRighe()-2 && logica->getInMappa(player->getX()+1, player->getY()).getTipo()==0)
		         {
		            logica->setInMappa(player->getX()+1,player->getY(),3);
		            logica->setInMappaDirezione(player->getX()+1,player->getY(),DOWN);
		            player->setBarile(false);
		            player->setDistruttibile(false);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		         }

		         if(player->getDirezione()==LEFT && player->getY()>0 && logica->getInMappa(player->getX(),player->getY()-1).getTipo()==0)
		         {
		            logica->setInMappa(player->getX(),player->getY()-1,3);
		            logica->setInMappaDirezione(player->getX(),player->getY()-1,LEFT);
		            player->setBarile(false);
		            player->setDistruttibile(false);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		         }
		      
		         if(player->getDirezione()==RIGHT && player->getY()<logica->getColonne()-2 && logica->getInMappa(player->getX(),player->getY()+1).getTipo()==0)
		         {
		            logica->setInMappa(player->getX(),player->getY()+1,3);
		            logica->setInMappaDirezione(player->getX(),player->getY()+1,RIGHT);
		            player->setBarile(false);
		            player->setDistruttibile(false);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		         }
		      } //FINE CONTROLLO
		      
		      //SE IL PLAYER NON HA IL BARILE (NON DISTRUTTIBILE), CON IL TASTO SPACE LO PRENDE
		      if(key[KEY_SPACE] &&player->getBarile()==false && player->getVisibile())
		      {
		         if(player->getDirezione()==UP && player->getX()>0 && logica->getInMappa(player->getX()-1, player->getY()).getTipo()==5)
		         {
		            logica->setInMappa(player->getX()-1,player->getY(),0);
		            player->setBarile(true);
		            player->setDistruttibile(false);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		            player->incrementaContatoreBarili();
		         }
		      
		         if(player->getDirezione()==DOWN && player->getX()<logica->getRighe() && logica->getInMappa(player->getX()+1, player->getY()).getTipo()==5)
		         {
		            logica->setInMappa(player->getX()+1,player->getY(),0);
		            player->setBarile(true);
		            player->setDistruttibile(false);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		            player->incrementaContatoreBarili();
		         }
		      
		         if(player->getDirezione()==LEFT && player->getY()>0 && logica->getInMappa(player->getX(),player->getY()-1).getTipo()==5)
		         {
		            logica->setInMappa(player->getX(),player->getY()-1,0);
		            player->setBarile(true);
		            player->setDistruttibile(false);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		            player->incrementaContatoreBarili();
		         }
		      
		         if(player->getDirezione()==RIGHT && player->getY()<logica->getColonne() && logica->getInMappa(player->getX(),player->getY()+1).getTipo()==5)
		         {
		            logica->setInMappa(player->getX(),player->getY()+1,0);
		            player->setBarile(true);
		            player->setDistruttibile(false);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		            player->incrementaContatoreBarili();
		         }
		      } //FINE CONTROLLO
		      
		      //SE IL PLAYER HA GIA IL BARILE (NON DISTRUTTIBILE), CON IL TASTO SPACE LO LANCIA 
		      if(key[KEY_SPACE] && player->getBarile()==true && player->getDistruttibile()==false && player->getVisibile())
		      {
		         if(player->getDirezione()==UP && player->getX()>0 && logica->getInMappa(player->getX()-1, player->getY()).getTipo()==0)
		         {
		            logica->setInMappa(player->getX()-1,player->getY(),5);
		            logica->setInMappaDirezione(player->getX()-1,player->getY(),UP);
		            player->setBarile(false);
		            player->setDistruttibile(false);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		         }

		         if(player->getDirezione()==DOWN && player->getX()<logica->getRighe()-2 && logica->getInMappa(player->getX()+1, player->getY()).getTipo()==0)
		         {
		            logica->setInMappa(player->getX()+1,player->getY(),5);
		            logica->setInMappaDirezione(player->getX()+1,player->getY(),DOWN);
		            player->setBarile(false);
		            player->setDistruttibile(false);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		         }

		         if(player->getDirezione()==LEFT && player->getY()>0 && logica->getInMappa(player->getX(),player->getY()-1).getTipo()==0)
		         {
		            logica->setInMappa(player->getX(),player->getY()-1,5);
		            logica->setInMappaDirezione(player->getX(),player->getY()-1,LEFT);
		            player->setBarile(false);
		            player->setDistruttibile(false);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		         }
		      
		         if(player->getDirezione()==RIGHT && player->getY()<logica->getColonne()-2 && logica->getInMappa(player->getX(),player->getY()+1).getTipo()==0)
		         {
		            logica->setInMappa(player->getX(),player->getY()+1,5);
		            logica->setInMappaDirezione(player->getX(),player->getY()+1,RIGHT);
		            player->setBarile(false);
		            player->setDistruttibile(false);
		            setRedraw(true);
		            key[KEY_SPACE]=false;
		         }
		      }
	      } //FINE CONTROLLO

	      //TIMER2
	      if(ev.timer.source==timer2)
	      {
	      	logica->slide();
		      
		      //VERIFICA SE UN NEMICO VIENE COLPITO DA UN BARILE E MUORE
		      for(int i=0;i<nemici.size();i++)
		      {
		         if(nemici[i]->getVisibile() && (logica->getInMappa(nemici[i]->getX(),nemici[i]->getY()).getTipo()==3 || logica->getInMappa(nemici[i]->getX(),nemici[i]->getY()).getTipo()==5))
		         {
		            nemici[i]->setVisibile(false);
		         }
		      }
		     
		      //VERIFICA SE IL PLAYER MUORE UNA VOLTA COLPITO DAL NEMICO 
		      for(int i=0;i<nemici.size();i++)
		      {
		         if(nemici[i]->getX()==player->getX() && nemici[i]->getY()==player->getY() && player->getVisibile() && player->getInvincibile()==false && nemici[i]->getVisibile())
		         {
		            player->setVite(player->getVite()-1);
		            player->setVisibile(false);
		            player->setBarile(false);
		            player->setDistruttibile(false);
		            player->azzeraContatoreBarili();
		            if(player->getVite()<=0)
		            {
		               menu();
		               cout<<"HAI PERSO..."; 
		               setDoexit(true);
		            }
		         }    
		      } 
		      
		      //VERIFICA SE IL PLAYER MUORE UNA VOLTA COLPITO DAL CORSARO
		      for(int i=0;i<corsari.size();i++)
		      {
		         if(corsari[i]->getX()==player->getX() && corsari[i]->getY()==player->getY() && player->getVisibile() && player->getInvincibile()==false && corsari[i]->getVisibile())
		         {
		            player->setVite(player->getVite()-1);
		            player->setVisibile(false);
		            player->setBarile(false);
		            player->setDistruttibile(false);
		            player->azzeraContatoreBarili();
		            if(player->getVite()<=0)
		            {
		               menu();
		               cout<<"HAI PERSO...";
		               setDoexit(true);
		            }
		         }
		      
		      }
		     
		      //VERIFICA SE IL CORSARO VIENE COLPITO DA UN BARILE
		      for(int i=0;i<corsari.size();i++)
		      {
		         if(corsari[i]->getVisibile()==false)
		         {
		            int temp=0;
		            bool controlloDirezione=false;
		            if(logica->getInMappa(spawnCorsaro[i].getA(),spawnCorsaro[i].getB()).getTipo()==0)
		            {
		               corsari[i]->setX(spawnCorsaro[i].getA());
		               corsari[i]->setY(spawnCorsaro[i].getB());
		               corsari[i]->setVisibile(true);  
		               break;
		            }
		            
		            while(logica->getInMappa(1,temp).getTipo()!=0)
		            {
		               if(temp==logica->getColonne()-1)
		                  break;
		               temp++;
		               if(logica->getInMappa(1,temp).getTipo()==0)
		                  controlloDirezione=true;
		            
		            }
		            
		            if(controlloDirezione==false)
		            {
		               temp=0;
		               while(logica->getInMappa(logica->getRighe()-2,temp).getTipo()!=0)
		               {
		                  if(temp==logica->getColonne()-1)
		                  	break;
		                  temp++;
		               }
		            }
		            
		            if(controlloDirezione)
		               corsari[i]->setX(1);
		            else
		               corsari[i]->setX(logica->getRighe()-2);
		            
		            corsari[i]->setY(temp);
		            corsari[i]->setVisibile(true);   
		         }
		         
		         if(corsari[i]->getVisibile() && (logica->getInMappa(corsari[i]->getX(),corsari[i]->getY()).getTipo()==3 || logica->getInMappa(corsari[i]->getX(),corsari[i]->getY()).getTipo()==5))
		         {
		            corsari[i]->setVisibile(false);
		         }
		      }
		      
		      //LOGICA MOVIMENTO DEI NEMICI
		      for(int i=0;i<nemici.size();i++)
		      {
		         vector<Direzione> direzioni; 
		         bool movimento=false;
		         if(nemici[i]->getVisibile() && nemici[i]->getDirezione()==UP && nemici[i]->getX()>0 && logica->getInMappa(nemici[i]->getX()-1,nemici[i]->getY()).getTipo()==0)
		         {
		         	if((logica->getInLogica(nemici[i]->getX()-1,nemici[i]->getY())!='E') && (logica->getInLogica(nemici[i]->getX()-1,nemici[i]->getY())!='C'))
		         	{
			            direzioni.push_back(UP);
			            movimento=true;
		         	}
	         	}
		         
		         if(nemici[i]->getVisibile() && nemici[i]->getDirezione()==DOWN && nemici[i]->getX()<logica->getRighe() && logica->getInMappa(nemici[i]->getX()+1,nemici[i]->getY()).getTipo()==0)
		         {
		         	if((logica->getInLogica(nemici[i]->getX()+1,nemici[i]->getY())!='E') && (logica->getInLogica(nemici[i]->getX()+1,nemici[i]->getY())!='C'))
		         	{
		            	direzioni.push_back(DOWN);
		            	movimento=true;
		         	}
	         	}

		         if(nemici[i]->getVisibile() && nemici[i]->getDirezione()==RIGHT && nemici[i]->getY()<logica->getColonne() && logica->getInMappa(nemici[i]->getX(),nemici[i]->getY()+1).getTipo()==0)
		         {
		         	if((logica->getInLogica(nemici[i]->getX(),nemici[i]->getY()+1)!='E') && (logica->getInLogica(nemici[i]->getX(),nemici[i]->getY()+1)!='C'))
		         	{
		            	direzioni.push_back(RIGHT);
		            	movimento=true;
		         	}
	         	}

		          if(nemici[i]->getVisibile() && nemici[i]->getDirezione()==LEFT && nemici[i]->getY()>0 && logica->getInMappa(nemici[i]->getX(),nemici[i]->getY()-1).getTipo()==0)
		         {
		         	if((logica->getInLogica(nemici[i]->getX(),nemici[i]->getY()-1)!='E') && (logica->getInLogica(nemici[i]->getX(),nemici[i]->getY()-1)!='C'))
		            direzioni.push_back(LEFT);
		            movimento=true;
		         }
		         
		         if(nemici[i]->getVisibile() && ev.type == ALLEGRO_EVENT_TIMER)
		         {
		            if(movimento==false)
		            {
		               if(logica->getInMappa(nemici[i]->getX()-1,nemici[i]->getY()).getTipo()==0)
		                  direzioni.push_back(UP);
		               
		               if(logica->getInMappa(nemici[i]->getX()+1,nemici[i]->getY()).getTipo()==0)
		                  direzioni.push_back(DOWN);
		               
		               if(logica->getInMappa(nemici[i]->getX(),nemici[i]->getY()-1).getTipo()==0)
		                  direzioni.push_back(LEFT);
		               
		               if(logica->getInMappa(nemici[i]->getX(),nemici[i]->getY()+1).getTipo()==0)
		                  direzioni.push_back(RIGHT);
		            }
		               
		            if(direzioni.empty()==false)
		            {
		               int A;
		               srand((unsigned)time(NULL));
		               A=rand() % direzioni.size();
		            
		               if(direzioni[A]==UP)
		               {
		                  logica->setInLogica(nemici[i]->getX(),nemici[i]->getY(),'0');
		                  nemici[i]->setX(nemici[i]->getX()-1);
		                  logica->setInLogica(nemici[i]->getX(), nemici[i]->getY(),'E');
		                  nemici[i]->setDirezione(UP);
		                  setRedraw(true);
		               }
		               if(direzioni[A]==DOWN)
		               {
		                  logica->setInLogica(nemici[i]->getX(),nemici[i]->getY(),'0');
		                  nemici[i]->setX(nemici[i]->getX()+1);
		                  logica->setInLogica(nemici[i]->getX(), nemici[i]->getY(),'E');
		                  nemici[i]->setDirezione(DOWN);
		                  setRedraw(true);
		               }
		               if(direzioni[A]==LEFT)
		               {
		                  logica->setInLogica(nemici[i]->getX(),nemici[i]->getY(),'0');
		                  nemici[i]->setY(nemici[i]->getY()-1);
		                  logica->setInLogica(nemici[i]->getX(), nemici[i]->getY(),'E');
		                  nemici[i]->setDirezione(LEFT);
		                  setRedraw(true);
		               }  
		               if(direzioni[A]==RIGHT)
		               {
		                  logica->setInLogica(nemici[i]->getX(),nemici[i]->getY(),'0');
		                  nemici[i]->setY(nemici[i]->getY()+1);
		                  logica->setInLogica(nemici[i]->getX(), nemici[i]->getY(),'E');
		                  nemici[i]->setDirezione(RIGHT);
		                  setRedraw(true);
		               }
		            }
		         }  
		      } //FINE LOGICA MOVIMENTO NEMICI
		      
		      //LOGICA MOVIMENTO DEL CORSARO
		      for(int i=0;i<corsari.size();i++)
		      {
		      	vector<Direzione> direzioni; 
		         bool movimento=false;
		         if(corsari[i]->getVisibile() && corsari[i]->getDirezione()==UP && corsari[i]->getX()>0 && logica->getInMappa(corsari[i]->getX()-1,corsari[i]->getY()).getTipo()==0)
		         {
		         	if((logica->getInLogica(corsari[i]->getX()-1,corsari[i]->getY())!='E') && (logica->getInLogica(corsari[i]->getX()-1,corsari[i]->getY())!='C'))
		         	{
		            	direzioni.push_back(UP);
		            	movimento=true;
		         	}
	         	}

		         if(corsari[i]->getVisibile() && corsari[i]->getDirezione()==DOWN && corsari[i]->getX()<logica->getRighe() && logica->getInMappa(corsari[i]->getX()+1,corsari[i]->getY()).getTipo()==0)
		         {
		         	if((logica->getInLogica(corsari[i]->getX()+1,corsari[i]->getY())!='E') && (logica->getInLogica(corsari[i]->getX()+1,corsari[i]->getY())!='C'))
		         	{
			            direzioni.push_back(DOWN);
			            movimento=true;
		            }
		         }
		         
		         if(corsari[i]->getVisibile() && corsari[i]->getDirezione()==RIGHT && corsari[i]->getY()<logica->getColonne() && logica->getInMappa(corsari[i]->getX(),corsari[i]->getY()+1).getTipo()==0)
		         {
		         	if((logica->getInLogica(corsari[i]->getX(),corsari[i]->getY()+1)!='E') && (logica->getInLogica(corsari[i]->getX(),corsari[i]->getY()+1)!='C'))
		         	{
			            direzioni.push_back(RIGHT);
			            movimento=true;
		            }
		         }
		         
		         if(corsari[i]->getVisibile() && corsari[i]->getDirezione()==LEFT && corsari[i]->getY()>0 && logica->getInMappa(corsari[i]->getX(),corsari[i]->getY()-1).getTipo()==0)
		         {
		         	if((logica->getInLogica(corsari[i]->getX(),corsari[i]->getY()-1)!='E') && (logica->getInLogica(corsari[i]->getX(),corsari[i]->getY()-1)!='C'))
		         	{
			            direzioni.push_back(LEFT);
			            movimento=true;
		            }
		         }
		         
		         if(corsari[i]->getVisibile()) 
		         {
		            if(movimento==false)
		            {
		               if(logica->getInMappa(corsari[i]->getX()-1,corsari[i]->getY()).getTipo()==0)
		                  direzioni.push_back(UP);
		               if(logica->getInMappa(corsari[i]->getX()+1,corsari[i]->getY()).getTipo()==0)
		                  direzioni.push_back(DOWN);
		               if(logica->getInMappa(corsari[i]->getX(),corsari[i]->getY()-1).getTipo()==0)
		                  direzioni.push_back(LEFT);
		               if(logica->getInMappa(corsari[i]->getX(),corsari[i]->getY()+1).getTipo()==0)
		                  direzioni.push_back(RIGHT);
		            }
		            if(direzioni.empty()==false)
		            {
		               int A;
		               srand((unsigned)time(NULL));
		               A=rand() % direzioni.size();
		               
		               if(direzioni[A]==UP)
		               {
		                  logica->setInLogica(corsari[i]->getX(),corsari[i]->getY(),'0');
		                  corsari[i]->setX(corsari[i]->getX()-1);
		                  logica->setInLogica(corsari[i]->getX(), corsari[i]->getY(),'C');
		                  corsari[i]->setDirezione(UP);
		                  setRedraw(true);
		               }
		               if(direzioni[A]==DOWN)
		               {
		                  logica->setInLogica(corsari[i]->getX(),corsari[i]->getY(),'0');
		                  corsari[i]->setX(corsari[i]->getX()+1);
		                  logica->setInLogica(corsari[i]->getX(), corsari[i]->getY(),'C');
		                  corsari[i]->setDirezione(DOWN);
		                  setRedraw(true);
		               }
		               if(direzioni[A]==LEFT)
		               {
		                  logica->setInLogica(corsari[i]->getX(),corsari[i]->getY(),'0');
		                  corsari[i]->setY(corsari[i]->getY()-1);
		                  logica->setInLogica(corsari[i]->getX(), corsari[i]->getY(),'C');
		                  corsari[i]->setDirezione(LEFT);
		                  setRedraw(true);
		               }  
		               if(direzioni[A]==RIGHT)
		               {
		                  logica->setInLogica(corsari[i]->getX(),corsari[i]->getY(),'0');
		                  corsari[i]->setY(corsari[i]->getY()+1);
		                  logica->setInLogica(corsari[i]->getX(), corsari[i]->getY(),'C');
		                  corsari[i]->setDirezione(RIGHT);
		                  setRedraw(true);
		               }
		            }  
		         }
	      	} //FINE LOGICA MOVIMENTO CORSARO
	   	}   
   	}         
   } //CHIUSURA WHILE
} //CHIUSURA METODO START()

//Attiva i tasti se vengono premuti
bool GameManager:: attivazione(ALLEGRO_EVENT ev)
{
   switch(ev.keyboard.keycode) 
   {
      case ALLEGRO_KEY_UP:
         key[KEY_UP]=true;
         break;

      case ALLEGRO_KEY_DOWN:
         key[KEY_DOWN]=true;
         break;

      case ALLEGRO_KEY_LEFT: 
         key[KEY_LEFT]=true;
         break;

      case ALLEGRO_KEY_RIGHT:
         key[KEY_RIGHT]=true;
         break;
         
      case ALLEGRO_KEY_SPACE:
         key[KEY_SPACE]=true;
         break;
           
      case ALLEGRO_KEY_ENTER:
         key[KEY_ENTER]=true;
         break;
   }
}

//Disattiva i tasti se vengono rilasciati
bool GameManager::disattivazione(ALLEGRO_EVENT ev)
{
   switch(ev.keyboard.keycode) 
   {
      case ALLEGRO_KEY_UP:
         key[KEY_UP]=false;
         break;

      case ALLEGRO_KEY_DOWN:
         key[KEY_DOWN]=false;
         break;

      case ALLEGRO_KEY_LEFT: 
         key[KEY_LEFT]=false;
         break;
      
      case ALLEGRO_KEY_RIGHT:
         key[KEY_RIGHT]=false;
         break;
         
      case ALLEGRO_KEY_SPACE:
         key[KEY_SPACE]=false;
         break;
         
      case ALLEGRO_KEY_ENTER:
         key[KEY_ENTER]=false;
         break;
               
      case ALLEGRO_KEY_ESCAPE:
         setDoexit(true);
         break;
   }
}

bool GameManager::getRedraw() const
{
   return redraw;
}

void GameManager::setRedraw(bool r)
{
   redraw=r;
}

bool GameManager::getDoexit() const
{
   return doexit;
}

void GameManager::setDoexit(bool value)
{
   doexit=value;
}

//Metodo che permette di visualizzare le immagini sul display.
void GameManager::Grafica()
{
   setRedraw(false);
   al_draw_scaled_bitmap(sfondo, 0, 0, 1550,800,0,0,logica->getColonne()*50 ,logica->getRighe()*50,0);

   //FOR PER LE IMMAGINI DEI NEMICI
   for(int i=0; i<nemici.size();i++)
   {
      if(nemici[i]->getVisibile())
      {
         if(nemici[i]->getDirezione()==RIGHT)
         {
            al_set_target_bitmap(al_get_backbuffer(display));
            al_draw_bitmap(immaginiEn[0], nemici[i]->getY()*50,nemici[i]->getX()*50,0);
         }
         if(nemici[i]->getDirezione()==LEFT)
         {
            al_set_target_bitmap(al_get_backbuffer(display));
            al_draw_bitmap(immaginiEn[1], nemici[i]->getY()*50,nemici[i]->getX()*50,0);
         }
         if(nemici[i]->getDirezione()==UP)
         {
            al_set_target_bitmap(al_get_backbuffer(display));
            al_draw_bitmap(immaginiEn[2], nemici[i]->getY()*50,nemici[i]->getX()*50,0);
         }
         if(nemici[i]->getDirezione()==DOWN)
         {
            al_set_target_bitmap(al_get_backbuffer(display));
            al_draw_bitmap(immaginiEn[3], nemici[i]->getY()*50,nemici[i]->getX()*50,0);
         }
      }
   }
   
   //FOR PER LE IMMAGINI DEI CORSARI
   for(int i=0;i<corsari.size();i++)
   {
      if(corsari[i]->getVisibile())
      {
         if(corsari[i]->getDirezione()==RIGHT)
         {
            al_set_target_bitmap(al_get_backbuffer(display));
            al_draw_bitmap(immaginiCo[1], corsari[i]->getY()*50,corsari[i]->getX()*50,0);
         }
         if(corsari[i]->getDirezione()==LEFT)
         {
            al_set_target_bitmap(al_get_backbuffer(display));
            al_draw_bitmap(immaginiCo[3], corsari[i]->getY()*50,corsari[i]->getX()*50,0);
         }
         if(corsari[i]->getDirezione()==UP)
         {
            al_set_target_bitmap(al_get_backbuffer(display));
            al_draw_bitmap(immaginiCo[0], corsari[i]->getY()*50,corsari[i]->getX()*50,0);
         }
         if(corsari[i]->getDirezione()==DOWN)
         {
            al_set_target_bitmap(al_get_backbuffer(display));
            al_draw_bitmap(immaginiCo[2], corsari[i]->getY()*50,corsari[i]->getX()*50,0);
         }
      }
   }
   
   //FOR PER LE IMMAGINI DEI BARILI 
   for(int i=0; i<logica->getRighe();i++)
   {
      for(int j=0;j<logica->getColonne();j++)
      {
         if(logica->getInMappa(i,j).getTipo()==1 || logica->getInMappa(i,j).getTipo()==3)
         {
            al_set_target_bitmap(al_get_backbuffer(display));
            al_draw_bitmap(barile, j*50,i*50,0);
         }
         
         if(logica->getInMappa(i,j).getTipo()==2)
         {
            al_set_target_bitmap(al_get_backbuffer(display));
            al_draw_bitmap(contorno, j*50,i*50,0);
         }
         
         if(logica->getInMappa(i,j).getTipo()==5)
         {
            al_set_target_bitmap(al_get_backbuffer(display));
            al_draw_bitmap(moneta, j*50,i*50,0);
         }
      }
   }
   
   //IMMAGINI PER IL PLAYER
   if(player->getVisibile())
   {  
      if(player->getDirezione()==UP)
      {
      	if(player->getInvincibile()==false)
      	{	
         	al_set_target_bitmap(al_get_backbuffer(display));
         	al_draw_bitmap(immaginiPg[3], player->getY()*50,player->getX()*50,0);
         }

         else
         {
         	al_set_target_bitmap(al_get_backbuffer(display));
         	al_draw_bitmap(immaginiPgI[3], player->getY()*50,player->getX()*50,0);
         }	
      }
      
      if(player->getDirezione()==DOWN)
      {
      	if(player->getInvincibile()==false)
      	{
	         al_set_target_bitmap(al_get_backbuffer(display));
	         al_draw_bitmap(immaginiPg[2], player->getY()*50,player->getX()*50,0);
	      }

	      else
      	{
      		al_set_target_bitmap(al_get_backbuffer(display));
	         al_draw_bitmap(immaginiPgI[2], player->getY()*50,player->getX()*50,0);
      	}
      }
      
      if(player->getDirezione()==LEFT)
      {
      	if(player->getInvincibile()==false)
      	{
	         al_set_target_bitmap(al_get_backbuffer(display));
	         al_draw_bitmap(immaginiPg[0], player->getY()*50,player->getX()*50,0);
	      }

	      else
	      {
	      	al_set_target_bitmap(al_get_backbuffer(display));
	         al_draw_bitmap(immaginiPgI[0], player->getY()*50,player->getX()*50,0);
	      }
      }
      
      if(player->getDirezione()==RIGHT)
      {
      	if(player->getInvincibile()==false)
      	{
	         al_set_target_bitmap(al_get_backbuffer(display));
	         al_draw_bitmap(immaginiPg[1], player->getY()*50,player->getX()*50,0);
	      }

	      else
	      {
	      	al_set_target_bitmap(al_get_backbuffer(display));
	         al_draw_bitmap(immaginiPgI[1], player->getY()*50,player->getX()*50,0);
	      }
      }
   }  

   //IMMAGINE PER LE VITE
   for(int i=0; i<player->getVite(); i++)
   {
   	al_set_target_bitmap(al_get_backbuffer(display));
   	al_draw_bitmap(immaginiPg[2], i*50, 0,0);
   }

   //IMMAGINE CHE MOSTRA SE IL PLAYER HA IN MANO UN BARILE (DISTRUTTIBILE O NON DISTRUTTIBILE) OPPURE NO
   if(player->getBarile())
   {
   	if(player->getDistruttibile())
   	{
   		al_set_target_bitmap(al_get_backbuffer(display));
   		al_draw_bitmap(barilePreso, (logica->getColonne()-1)*50, 0,0);
   	}

   	else
   	{
   		al_set_target_bitmap(al_get_backbuffer(display));
   		al_draw_bitmap(moneta, (logica->getColonne()-1)*50, 0,0);
   	}
   }
}

//Il metodo avanzaDiLivello() si occupa di preparare la logica del gioco ogni volta che il livello cambia.
void GameManager::avanzaDiLivello()
{
   if(livello>=3)
   {
      menu();
      doexit=true;
      cout<<"HAI VINTO!"<<endl;
      return;
   }
   
   if(livello==0)
      livello=1;
   
   else if(livello==1)
      livello=2;
  
   else if(livello==2)
      livello=3;
   
   logica->riempi(livello);
   player->setVisibile(false);
 
   if(!corsari.empty()){
      corsari.clear();
      spawnCorsaro.clear();
   }
   
   if(!nemici.empty())
      nemici.clear();
      
   for(int i=0;i<logica->getRighe();i++)
   {
      for(int j=0;j<logica->getColonne();j++)
      {
         if(logica->getInMappa(i,j).getTipo()==4)
         {
            Enemy* temp=new Enemy(i,j,true,DOWN);
            logica->setInLogica(i,j,'E');
            logica->setInMappa(i,j,0);
            nemici.push_back(temp);
         }
        
         if(logica->getInMappa(i,j).getTipo()==7)
         {
            Corsaro* temp=new Corsaro(i,j,true,DOWN);
            logica->setInLogica(i,j,'C');
            logica->setInMappa(i,j,0);
            corsari.push_back(temp);
            Coordinate c(i,j);
            spawnCorsaro.push_back(c);
         }
      }

   }
  
   player->setX(logica->getRighe()/2);
   player->setY(logica->getColonne()/2);
   logica->setInLogica(player->getX(), player->getY(), 'P');   
   player->setVisibile(true);
   setRedraw(false);
}

//Il metodo menu() permette di visualizzare un menù (che sia di avvio, vincita o game over)
void GameManager::menu()
{
 while(!key[KEY_ENTER] && !getDoexit())
   {  
      if(livello==0)
         al_draw_scaled_bitmap(menu1, 0, 0, 1550,800,0,0, SCREEN_W,SCREEN_H,0);
      else
      {
         if(player->getVite()<=0)
           al_draw_scaled_bitmap(sconfitta, 0, 0, 1550,800,0,0, SCREEN_W,SCREEN_H,0);
         else if(player->getVite()>=1)
           al_draw_scaled_bitmap(vittoria, 0, 0, 1550,800,0,0, SCREEN_W,SCREEN_H,0);
      }
      al_flip_display();
      
      //CREAZIONE DELL'EVENTO DI USCITA DAL MENU'
      ALLEGRO_EVENT evento;
      al_wait_for_event(event_queue, &evento);
      if(evento.type==ALLEGRO_EVENT_DISPLAY_CLOSE)
         setDoexit(true);
         
      if(evento.type==ALLEGRO_EVENT_KEY_UP)
      {
         if(evento.keyboard.keycode==ALLEGRO_KEY_ENTER)
            key[KEY_ENTER]=false;
      }
         
      if(evento.type==ALLEGRO_EVENT_KEY_DOWN)
      {
         if(evento.keyboard.keycode==ALLEGRO_KEY_ENTER)
            key[KEY_ENTER]=true;
         if(evento.keyboard.keycode==ALLEGRO_KEY_ESCAPE)
            exit(1);
      }
     
      if(key[KEY_ENTER] && livello>=3)
      	exit(1);
       
   }
}

GameManager::~GameManager()
{
   delete logica;
   delete player;
   
   al_destroy_bitmap(contorno);
   al_destroy_bitmap(sfondo);
   al_destroy_bitmap(barile);
   al_destroy_bitmap(barilePreso);
   al_destroy_bitmap(moneta);
   al_destroy_bitmap(vita);
   
   al_destroy_event_queue(event_queue); 
   al_destroy_timer(timer1); 
   al_destroy_timer(timer2); 
   al_destroy_display(display);
   immaginiPg.clear();
	immaginiPgI.clear();
   immaginiEn.clear();
   immaginiCo.clear();
   corsari.clear();
   nemici.clear();
}
