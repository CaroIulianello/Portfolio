//La classe Matrice contiene 2 matrici dinamiche di dimensione uguale (una di char, l'altra di Barili), che rappresentano i possibili movimenti logici del player nella "mappa di
// gioco". Inoltre ci sono due interi che rappresentano il numero di righe ed il numero di colonne delle matrici.

#include "Barile.h"
#include <stdio.h>
#include<iostream>
using namespace std;

class Matrice
{
   private:
      char **logica;
      Barile **mappa;
      int numRighe;
      int numColonne;
   public:
      Matrice(int);
      void stampa();
      void setInMappaDirezione(int,int,Direzione);
      void setInLogica(int,int,char);
      void setInMappa(int,int,int);
      int getRighe() const;
      int getColonne() const;
      char getInLogica(int,int) const;
      Barile getInMappa(int,int) const;
      bool slide();
      void riempi(int);
      ~Matrice();
};

Matrice:: Matrice(int liv)
{
   numRighe=0;
   numColonne=0;
}

//Il metodo riempi serve a riempire la matrice a partire del livello fornito come dato nel metodo.
//Per riempire la matrice usiamo la lettura da file, caricando i file (contenenti le mappe) presenti nella cartella del progetto.

void Matrice:: riempi(int liv)
{
   FILE*in;
   //In base al livello decidiamo quale file leggere
   if (liv==1)
      in=fopen("mappa/map1","r");
   
   else if (liv==2 || liv==3)
   {
      for(int i=0;i<numRighe;i++)
      {
         delete logica[i];
         delete mappa[i];
      }
      
      delete []mappa;
      delete []logica;
      
      if(liv==2)
         in=fopen("mappa/map2","r");
      
      if(liv==3)
         in=fopen("mappa/map3","r");
   }
   
   char valore=0;
   int righe=0;
   int colonne=0;
   
   fscanf(in,"%d",&righe);
   fscanf(in,"%d",&colonne);
   
   numRighe=righe;
   numColonne=colonne;
   logica=new char*[numRighe];
   mappa=new Barile*[numRighe];
   
   for (int i=0; i<numRighe;i++)  
   {  
      mappa[i]=new Barile[numColonne];
      logica[i]=new char[numColonne];
   }

   for (int i=0;i<numRighe;i++)
   {
      for (int j=0;j<numColonne;j++)	
      {
         fscanf(in, "%s", &valore);
         if(valore=='0')
         {
            Barile temp(0,NONE);
            mappa[i][j]=temp;
         }
         
         if(valore=='1')
         {
            Barile temp(1,NONE);
            mappa[i][j]=temp;
         }
         
         if(valore=='2')
         {
            Barile temp(2,NONE);
            mappa[i][j]=temp;
         }
         
         if(valore=='4')
         {
            Barile temp(4,NONE);
            mappa[i][j]=temp;
         }
         
         if(valore=='5')
         {
            Barile temp(5,NONE);
            mappa[i][j]=temp;
         }
         
         if(valore=='7')
         {
            Barile temp(7,NONE);
            mappa[i][j]=temp;  
         }
      }
   }

   for(int i=0;i<numRighe;i++)
      for(int j=0;j<numColonne;j++)
         logica[i][j]=0;
         
   fclose(in);
}

//il metodo stampa() della classe Matrice stampa su terminale entrambe le matrici
void Matrice:: stampa()
{
   for(int i=0;i<numRighe;i++)
   {
      for(int j=0;j<numColonne;j++)
         cout<<mappa[i][j].getTipo();

      cout<<endl;
   }
}

void Matrice:: setInMappaDirezione(int i,int j,Direzione d)
{
   mappa[i][j].setDirezione(d);
}

void Matrice:: setInMappa(int i,int j,int t)
{
   mappa[i][j].setTipo(t);
}

int Matrice:: getRighe() const
{
   return numRighe;
}

int Matrice:: getColonne() const
{
   return numColonne;
}

char Matrice:: getInLogica(int i,int j) const
{
   return logica[i][j];
}

Barile Matrice:: getInMappa(int i,int j) const
{
   return mappa[i][j];
}

void Matrice:: setInLogica(int i, int j, char c)
{
   logica[i][j]=c;
}

//il metodo slide() della classe Matrice viene chiamato periodicamente all'interno della classe GameManager. Serve a muovere di una posizione (se essa è valida) l'oggetto barile 
//in base alla direzione del lancio iniziale, aggiornando la variabile booleana "spostato" presente in Barile.
bool Matrice:: slide()
{
   bool r=false;
   
   for(int i=0;i<numRighe;i++)
      for(int j=0;j<numColonne;j++)
         mappa[i][j].setSpostato(false);
      
   for(int i=0;i<numRighe;i++)
   {
      for(int j=0;j<numColonne;j++)
      {
         //se il Barile è distruttibile, vengono effettuati questi controlli per verificare il movimento del barile ed eventualmente rimuoverlo se incontra un ostacolo.
         if(mappa[i][j].getTipo()==3 && mappa[i][j].getDirezione()==RIGHT && j<numColonne-1 && mappa[i][j].getSpostato()==false) 
         {
            if(mappa[i][j+1].getTipo()==0 || mappa[i][j+1].getTipo()==4 || mappa[i][j+1].getTipo()==7)
            {
               setInMappa(i,j+1,3);
               setInMappaDirezione(i,j+1,RIGHT);
               mappa[i][j+1].setSpostato(true);
            }
            setInMappa(i,j,0);
            r=true;
         }
         
         if(mappa[i][j].getTipo()==3 && mappa[i][j].getDirezione()==LEFT && j>0 && mappa[i][j].getSpostato()==false)
         {
            if(mappa[i][j-1].getTipo()==0 || mappa[i][j-1].getTipo()==4 || mappa[i][j-1].getTipo()==7)
	         {
                setInMappa(i,j-1,3);
                setInMappaDirezione(i,j-1,LEFT);
                mappa[i][j-1].setSpostato(true);
	         }
            setInMappa(i,j,0);
            r=true;
         }
         
         if(mappa[i][j].getTipo()==3 && mappa[i][j].getDirezione()==UP && i>0 && mappa[i][j].getSpostato()==false)
         {
	         if(mappa[i-1][j].getTipo()==0 || mappa[i-1][j].getTipo()==4 || mappa[i-1][j].getTipo()==7)
	         {
               setInMappa(i-1,j,3);
               setInMappaDirezione(i-1,j,UP);
               mappa[i-1][j].setSpostato(true);
	         }
            setInMappa(i,j,0);
            r=true;
         }
         
         if(mappa[i][j].getTipo()==3 && mappa[i][j].getDirezione()==DOWN && i<numRighe-1 && mappa[i][j].getSpostato()==false)
         {
	         if(mappa[i+1][j].getTipo()==0 || mappa[i+1][j].getTipo()==4 || mappa[i+1][j].getTipo()==7)
 	         {
               setInMappa(i+1,j,3);
               setInMappaDirezione(i+1,j,DOWN);
               mappa[i+1][j].setSpostato(true);
	         }
            
            setInMappa(i,j,0);
            r=true;
         }
         
         //se il barile è indistruttibile, vengono effettuati controlli diversi in quanto esso non scompare dall mappa.
         if(mappa[i][j].getTipo()==5 && mappa[i][j].getDirezione()==RIGHT && j<numColonne-2 && mappa[i][j].getSpostato()==false) 
         {
            if(mappa[i][j+1].getTipo()==0 || mappa[i][j+1].getTipo()==4 || mappa[i][j+1].getTipo()==7)
            {
               setInMappa(i,j+1,5);
               setInMappaDirezione(i,j+1,RIGHT);
               mappa[i][j+1].setSpostato(true);
               setInMappa(i,j,0);
               r=true;
            }
            else
               mappa[i][j].setDirezione(NONE);
            
         }
         
         if(mappa[i][j].getTipo()==5 && mappa[i][j].getDirezione()==LEFT && j>1 && mappa[i][j].getSpostato()==false)
         {
            if(mappa[i][j-1].getTipo()==0 || mappa[i][j-1].getTipo()==4 || mappa[i][j-1].getTipo()==7)
	         {
               setInMappa(i,j-1,5);
               setInMappaDirezione(i,j-1,LEFT);
               mappa[i][j-1].setSpostato(true);
               setInMappa(i,j,0);
               r=true; 
	         }
	         else
	            mappa[i][j].setDirezione(NONE);
            
         }
         
         if(mappa[i][j].getTipo()==5 && mappa[i][j].getDirezione()==UP && i>1 && mappa[i][j].getSpostato()==false)
         {
	         if(mappa[i-1][j].getTipo()==0 || mappa[i-1][j].getTipo()==4 || mappa[i-1][j].getTipo()==7)
	         {
               setInMappa(i-1,j,5);
               setInMappaDirezione(i-1,j,UP);
               mappa[i-1][j].setSpostato(true);
               setInMappa(i,j,0);
               r=true;
	         }
	         else
	            mappa[i][j].setDirezione(NONE);
            
         }
         
         if(mappa[i][j].getTipo()==5 && mappa[i][j].getDirezione()==DOWN && i<numRighe-2 && mappa[i][j].getSpostato()==false)
         {
	         if(mappa[i+1][j].getTipo()==0 || mappa[i+1][j].getTipo()==4 || mappa[i+1][j].getTipo()==7)
 	         {
               setInMappa(i+1,j,5);
               setInMappaDirezione(i+1,j,DOWN);
               mappa[i+1][j].setSpostato(true);
               setInMappa(i,j,0);
               r=true;
	         }
            else
	            mappa[i][j].setDirezione(NONE);
         }
         
      }
   }
 
   return r;
}

Matrice:: ~Matrice()
{
   for(int i=0;i<numRighe;i++)
   {
      delete logica[i];
      delete mappa[i];
   }
  
   delete []mappa;
   delete []logica;
}
