//Classe che gestisce due interi che indicano due coordinate, con rispettivi costruttori, get, set ed operatori.

class Coordinate
{
   private:
      int a;
      int b;
   public:
      Coordinate();
      Coordinate(int,int);
      int getA() const;
      int getB() const;
      void setA(int);
      void setB(int);
      bool operator==(Coordinate&);
      bool operator<(Coordinate&);
};

Coordinate:: Coordinate()
{
   a=0;
   b=0;
}

Coordinate:: Coordinate(int a, int b)
{
   this->a=a;
   this->b=b;
}

int Coordinate:: getA() const
{
   return a;
}

int Coordinate:: getB() const
{
   return b;
}

void Coordinate:: setA(int a)
{
   this->a=a;
}

void Coordinate:: setB(int b)
{
   this->b=b;
}

bool Coordinate:: operator==(Coordinate& right)
{
   return right.a==a && right.b==b;
}

bool Coordinate:: operator<(Coordinate& right)
{
   return right.a<a && right.b<b;
}
