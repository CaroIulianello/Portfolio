//La Classe Player eredita in modo public da DynamicObject e aggiunge successivamente diversi dati privati:
// int vite, intero che rappresetna le vite del Player. Una volta azzerate, il giocatore perde la partita.
// Direzione direzione, indica la direzione verso cui è girato il player.
// 2 booleane ("barile" e "distruttibile") che indicano quale tipo di barile ha in mano il player (senza barile, barile distruttibile, barile indistruttibile).
// int contatoreBarili, serve a contare i barili lanciati, così da permettere di ottene il bonus invincibilità. 
// bool invincibile, indica se il Player è invincibile o meno.

#include"DynamicObject.h"
class Player: public DynamicObject
{
   private:
      int vite;
      Direzione direzione;
      bool barile;
      bool distruttibile;
      int contatoreBarili;
      bool invincibile;

   public:
      Player();
      Player(int,int,bool,int, Direzione,bool,bool);
      bool getInvincibile() const;
      bool getBarile() const;
      int getVite() const;
      bool getDistruttibile() const;
      Direzione getDirezione() const;
      int getContatoreBarili() const;
      void setVite(int);
      void setBarile(bool);
      void setDirezione(Direzione);
      void setDistruttibile(bool);
      void setInvincibile(bool);
      void incrementaContatoreBarili();
      void azzeraContatoreBarili();
      virtual ~Player(){};
};

Player:: Player(): DynamicObject()
{
   vite=0;
   direzione=RIGHT;
   barile=false;
   distruttibile=false;
   contatoreBarili=0;
   invincibile=false;
}

Player:: Player(int x,int y,bool visibilita,int vite ,Direzione direzione,bool barile,bool distruttibile):DynamicObject(x,y,visibilita)
{
   this->vite=vite;
   this->direzione= direzione;
   this->barile=barile;
   this->distruttibile=distruttibile;
   this->contatoreBarili=0;
   this->invincibile=false;
}

int Player:: getVite() const
{
   return vite;
}

Direzione Player:: getDirezione() const
{
   return direzione;
}

bool Player:: getBarile() const
{
   return barile;
}

bool Player:: getDistruttibile() const
{
   return distruttibile;
}

bool Player:: getInvincibile() const
{
   return invincibile;
}

void Player:: setBarile(bool barile)
{
   this->barile=barile;
}

void Player:: setDirezione(Direzione d)
{
   this->direzione=d;
}

void Player:: setVite(int vite)
{
   this->vite=vite;
}

void Player:: setDistruttibile(bool distruttibile)
{
   this->distruttibile=distruttibile;
}

void Player:: setInvincibile(bool invincibile)
{
   this->invincibile=invincibile;
}

int Player:: getContatoreBarili() const
{
   return contatoreBarili;
}

//IncrementaContatoreBarili() è un metodo che incrementa l'intero contatoreBarili
void Player:: incrementaContatoreBarili()
{
   contatoreBarili++;
}

//AzzeraContatoreBarili() è un metodo che azzera l'intero contatoreBarili
void Player:: azzeraContatoreBarili()
{
   contatoreBarili=0;
}
