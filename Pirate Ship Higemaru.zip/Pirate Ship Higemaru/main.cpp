//main del gioco, si occupa della dichiarazione della classe GameManager e dell'avvio del gioco.

#include"GameManager.h"
using namespace std;

int main()
{
   GameManager M;
   M.avanzaDiLivello();
   M.start();

return 0;
}
