//La Classe Corsaro eredita in modo public dalla classe DynamicObject e aggiunge come dato privato la direzione.

class Corsaro: public DynamicObject
{
   private:
      Direzione direzione;
   public:
      Corsaro();
      Corsaro(int,int,bool,Direzione);
      Direzione getDirezione();
      void setDirezione(Direzione);
      virtual ~Corsaro() {}
};

Corsaro::Corsaro():DynamicObject()
{
   direzione=LEFT;
}

Corsaro::Corsaro(int x, int y, bool visibile, Direzione direzione):DynamicObject(x,y,visibile)
{
   this->direzione=direzione;
}

Direzione Corsaro::getDirezione()
{
   return direzione;
}

void Corsaro::setDirezione(Direzione direzione)
{
   this->direzione=direzione;
}
