//La classe Enemy eredita in modo public da DynamicObject e aggiunge la direzione come dato privato.

class Enemy: public DynamicObject
{
   private:
      Direzione direzione;
   public:
      Enemy();
      Enemy(int,int,bool,Direzione);
      Direzione getDirezione() const;
      void setDirezione(Direzione);
      virtual ~Enemy(){};
};
//Costruttori, Get e Set della Classe Enemy
Enemy:: Enemy(): DynamicObject()
{
   direzione=LEFT;
}

Enemy:: Enemy(int x,int y,bool visibile,Direzione direzione): DynamicObject(x,y,visibile)
{
   this->direzione=direzione;
}

Direzione Enemy:: getDirezione() const
{
   return direzione;
}

void Enemy:: setDirezione(Direzione d)
{
   direzione=d;
}

