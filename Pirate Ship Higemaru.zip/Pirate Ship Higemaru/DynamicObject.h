//DynamicObject è la classe alla base del progetto, essa viene ereditata da molte altre classi e contiene diverse informazioni di base, come le coordinate e la visibilità.

#include "Coordinate.h"

class DynamicObject
{
   private:
      Coordinate *coord; 
      bool visibile;
   public:
      DynamicObject();
      DynamicObject(int,int,bool);
      int getX() const;
      int getY() const;
      bool getVisibile() const;
      void setX(int);
      void setY(int);
      void setVisibile(bool);
      ~DynamicObject();
};

DynamicObject:: DynamicObject()
{
   coord=new Coordinate();
   visibile=true;
}

DynamicObject:: DynamicObject(int x,int y,bool visibile)
{
   coord=new Coordinate(x,y);
   this->visibile=visibile;
}

int DynamicObject:: getX() const
{
   return coord->getA();
}

int DynamicObject:: getY() const
{
   return coord->getB();
}

bool DynamicObject:: getVisibile() const
{
   return visibile;
}

void DynamicObject:: setX(int x)
{
   coord->setA(x);
}

void DynamicObject:: setY(int y)
{
   coord->setB(y);
}

void DynamicObject:: setVisibile(bool visibile)
{
   this->visibile=visibile;
}

DynamicObject::~DynamicObject()
{
   delete coord;
} 


