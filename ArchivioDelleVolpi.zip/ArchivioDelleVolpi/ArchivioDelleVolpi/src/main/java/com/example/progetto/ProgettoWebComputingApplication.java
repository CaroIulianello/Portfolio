package com.example.progetto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgettoWebComputingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgettoWebComputingApplication.class, args);
	} 
	
}