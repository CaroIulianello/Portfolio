package model;


public class Preferiti {
		String utente;
		String titolo;
		int idPreferiti;
		public String getUtente() {
			return utente;
		}
		public void setUtente(String utente) {
			this.utente = utente;
		}
		public String getTitolo() {
			return titolo;
		}
		public void setTitolo(String titolo) {
			this.titolo = titolo;
		}
		
		
}
